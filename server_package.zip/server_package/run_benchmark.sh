#!/bin/bash

# ============================================================================
# Mitochondrial Genome Alignment Benchmark Script (CUDA)
# ============================================================================

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 경로 설정
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

EXECUTABLE="nw_cuda_program"
MITO_DIR="mito"
RESULTS_DIR="results"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULTS_FILE="${RESULTS_DIR}/benchmark_${TIMESTAMP}.csv"
LOG_FILE="${RESULTS_DIR}/benchmark_${TIMESTAMP}.log"

echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Mitochondrial Genome Alignment Benchmark (CUDA)${NC}"
echo -e "${BLUE}============================================================${NC}\n"

# 실행파일 존재 확인
if [ ! -f "$EXECUTABLE" ]; then
    echo -e "${RED}[ERROR]${NC} 실행파일을 찾을 수 없습니다: ${EXECUTABLE}"
    exit 1
fi

# 실행파일에 실행 권한 부여
chmod +x "$EXECUTABLE"
echo -e "${GREEN}[INFO]${NC} 실행파일: ${EXECUTABLE}\n"

# 결과 디렉토리 생성
mkdir -p "$RESULTS_DIR"

# 미토콘드리아 파일 목록 가져오기
MITO_FILES=($(ls ${MITO_DIR}/*.fasta 2>/dev/null))

if [ ${#MITO_FILES[@]} -eq 0 ]; then
    echo -e "${RED}[ERROR]${NC} 미토콘드리아 FASTA 파일을 찾을 수 없습니다: ${MITO_DIR}"
    exit 1
fi

# Human 파일 찾기
HUMAN_FILE=""
for file in "${MITO_FILES[@]}"; do
    if [[ $(basename "$file") == *"Homosapiens"* ]] || [[ $(basename "$file") == *"human"* ]] || [[ $(basename "$file") == *"Human"* ]] || [[ $(basename "$file") == *"sapiens"* ]]; then
        HUMAN_FILE="$file"
        break
    fi
done

if [ -z "$HUMAN_FILE" ]; then
    echo -e "${RED}[ERROR]${NC} Human 미토콘드리아 파일을 찾을 수 없습니다."
    exit 1
fi

echo -e "${GREEN}[INFO]${NC} 기준 파일: $(basename "$HUMAN_FILE")"
echo -e "${GREEN}[INFO]${NC} 발견된 미토콘드리아 파일: ${#MITO_FILES[@]}개\n"
for file in "${MITO_FILES[@]}"; do
    basename "$file"
done
echo ""

# CSV 헤더 작성
echo "Sequence1,Sequence2,Score,ExecutionTime(s)" > "$RESULTS_FILE"

# 벤치마크 실행 (Human vs 나머지)
total_pairs=$((${#MITO_FILES[@]} - 1))
current_pair=0

echo -e "${BLUE}[BENCHMARK]${NC} Human과 ${total_pairs}개 종의 정렬을 수행합니다...\n"

for file in "${MITO_FILES[@]}"; do
    # Human 파일은 스킵
    if [ "$file" == "$HUMAN_FILE" ]; then
        continue
    fi

    file1="$HUMAN_FILE"
    file2="$file"

    name1=$(basename "$file1" .fasta)
    name2=$(basename "$file2" .fasta)

    current_pair=$((current_pair + 1))

    echo -e "${YELLOW}[${current_pair}/${total_pairs}]${NC} ${name1} vs ${name2}"

    # 실행 및 출력 캡처
    output=$(./"$EXECUTABLE" "$file1" "$file2" 2>&1)

    if [ $? -ne 0 ]; then
        echo -e "${RED}[ERROR]${NC} 실행 실패"
        echo "$output" >> "$LOG_FILE"
        continue
    fi

    # 결과 파싱
    exec_time=$(echo "$output" | grep "실행 시간:" | grep -oE '[0-9]+\.[0-9]+')
    score=$(echo "$output" | grep "정렬 점수:" | grep -oE '\-?[0-9]+')

    # CSV에 기록
    echo "${name1},${name2},${score},${exec_time}" >> "$RESULTS_FILE"

    echo -e "  점수: ${score}, 실행 시간: ${exec_time} 초\n"

    # 로그에 전체 출력 저장
    echo "===== ${name1} vs ${name2} =====" >> "$LOG_FILE"
    echo "$output" >> "$LOG_FILE"
    echo "" >> "$LOG_FILE"
done

# 정렬 결과 파일 정리
echo -e "${YELLOW}[CLEANUP]${NC} 정렬 결과 파일 정리 중..."
mkdir -p "${RESULTS_DIR}/alignments_${TIMESTAMP}"
mv *_vs_*_cuda_alignment.txt "${RESULTS_DIR}/alignments_${TIMESTAMP}/" 2>/dev/null

echo -e "\n${GREEN}============================================================${NC}"
echo -e "${GREEN}  벤치마크 완료!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo -e "결과 파일: ${RESULTS_FILE}"
echo -e "로그 파일: ${LOG_FILE}"
echo -e "정렬 파일: ${RESULTS_DIR}/alignments_${TIMESTAMP}/"
echo -e "${GREEN}============================================================${NC}\n"

# 실행 시간 통계 출력
echo -e "${BLUE}[통계]${NC} 실행 시간 요약:"
awk -F',' 'NR>1 {sum+=$4; if(min=="" || $4<min) min=$4; if($4>max) max=$4} END {
    printf "  최소: %.4f 초\n", min;
    printf "  최대: %.4f 초\n", max;
    printf "  평균: %.4f 초\n", sum/(NR-1);
}' "$RESULTS_FILE"

echo ""
