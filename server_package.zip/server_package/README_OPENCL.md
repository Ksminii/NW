# OpenCL Benchmark on NVIDIA GPU

이 패키지는 NVIDIA GPU에서 OpenCL을 사용하여 미토콘드리아 유전체 정렬을 수행합니다.

## 필요 사항

### 1. NVIDIA GPU
- CUDA 호환 GPU 필요
- RTX 4090 또는 기타 NVIDIA GPU

### 2. OpenCL 라이브러리
OpenCL은 보통 CUDA Toolkit과 함께 설치됩니다.

**확인:**
```bash
ldconfig -p | grep libOpenCL
```

**설치 (필요시):**
```bash
sudo apt-get update
sudo apt-get install nvidia-opencl-dev
```

### 3. 컴파일러
```bash
sudo apt-get install gcc
```

## 사용 방법

### 자동 실행 (권장)
```bash
./run_benchmark_opencl.sh
```

이 스크립트는:
1. OpenCL 설치 확인
2. 코드 컴파일
3. Human vs 10개 종 자동 정렬
4. 결과를 CSV로 저장
5. 통계 출력

### 수동 실행

**1. 컴파일:**
```bash
gcc -O3 -o nw_ocl_nvidia nw_ocl_generic.c -lOpenCL
```

**2. 실행:**
```bash
./nw_ocl_nvidia mito/Homosapiens_mitochondrion.fasta mito/Gorilla_mitochondrion.fasta
```

## OpenCL vs CUDA 비교

같은 NVIDIA GPU에서:

| 구현 | 특징 | 예상 성능 |
|------|------|----------|
| **CUDA** | NVIDIA 전용, 최적화됨 | 기준 (1.0x) |
| **OpenCL** | 크로스 플랫폼, 범용 | 비슷하거나 약간 느림 |

OpenCL은 CUDA보다 약간 느릴 수 있지만:
- 같은 코드가 AMD, Intel GPU에서도 작동
- 이식성이 뛰어남

## 결과 파일

실행 후 `results/` 디렉토리에 생성:
- `benchmark_opencl_nvidia_YYYYMMDD_HHMMSS.csv` - 벤치마크 결과
- `benchmark_opencl_nvidia_YYYYMMDD_HHMMSS.log` - 상세 로그
- `alignments_opencl_YYYYMMDD_HHMMSS/` - 정렬 결과 파일들

## 문제 해결

### OpenCL 라이브러리를 찾을 수 없음
```bash
# CUDA Toolkit 설치 확인
nvcc --version

# OpenCL 헤더 확인
ls /usr/local/cuda/include/CL/

# 라이브러리 경로 추가
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
```

### 컴파일 오류
```bash
# OpenCL 헤더 경로 명시
gcc -O3 -o nw_ocl_nvidia nw_ocl_generic.c \
    -I/usr/local/cuda/include \
    -L/usr/local/cuda/lib64 \
    -lOpenCL
```

### GPU를 찾을 수 없음
```bash
# GPU 확인
nvidia-smi

# OpenCL 플랫폼 확인
clinfo
```

## 파일 구조

```
server_package/
├── nw_ocl_generic.c          # OpenCL 소스 코드
├── run_benchmark_opencl.sh   # 자동 벤치마크 스크립트
├── nw_cuda_generic.cu         # CUDA 비교용
├── run_benchmark.sh           # CUDA 벤치마크 스크립트
├── mito/                      # 미토콘드리아 FASTA 파일들
│   ├── Homosapiens_mitochondrion.fasta
│   ├── Gorilla_mitochondrion.fasta
│   └── ...
└── results/                   # 결과 파일들
```

## 성능 비교 목표

1. **M3 OpenCL** (로컬) vs **NVIDIA OpenCL** (서버)
2. **NVIDIA OpenCL** vs **NVIDIA CUDA** (같은 GPU)
3. 통합 메모리 vs 디스크리트 GPU 아키텍처 차이 분석
