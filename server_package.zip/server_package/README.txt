사용법:

1. 이 폴더(server_package)를 VS Code로 서버에 드래그

2. 서버에서 실행:
   chmod +x run_benchmark.sh
   ./run_benchmark.sh

3. 결과 확인:
   results/benchmark_YYYYMMDD_HHMMSS.csv

CSV 형식:
   Sequence1,Sequence2,Score,ExecutionTime(s)

필수 요구사항:
   - CUDA Toolkit (nvcc)
   - NVIDIA GPU
